
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Appointment

SERVICE_CHOICES = [
    ('Haircut', 'Haircut'),
    ('Hair Coloring', 'Hair Coloring'),
    ('Facial', 'Facial'),
    ('Waxing', 'Waxing'),
    ('Manicure', 'Manicure'),
    ('Pedicure', 'Pedicure'),
    ('Bridal Makeup', 'Bridal Makeup'),
]

class RegisterForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2']

class AppointmentForm(forms.ModelForm):
    service = forms.ChoiceField(choices=SERVICE_CHOICES)

    class Meta:
        model = Appointment
        fields = ['service', 'date', 'time']
